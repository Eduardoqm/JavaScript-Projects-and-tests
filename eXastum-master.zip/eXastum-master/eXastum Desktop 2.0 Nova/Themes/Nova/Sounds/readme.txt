eXastum supports a startup, an alarm sound and an error sound.
You can place your own Login.wav file and an Error.wav and Alarm.mp3 files here and eXastum will play them in place of the defaults.