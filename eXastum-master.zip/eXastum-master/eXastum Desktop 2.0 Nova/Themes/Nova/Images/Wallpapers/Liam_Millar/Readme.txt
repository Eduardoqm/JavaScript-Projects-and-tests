These images were taken by Liam Millar, and copyright for the images belong to him.
The images are not at original resolution and have been optimised for use with eXastum.