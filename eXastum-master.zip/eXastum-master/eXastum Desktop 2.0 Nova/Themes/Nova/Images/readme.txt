Changing these images will effect your UI greatly and can give your desktop a new look and feel.
You can also edit the Skin.css file for even greater customization.