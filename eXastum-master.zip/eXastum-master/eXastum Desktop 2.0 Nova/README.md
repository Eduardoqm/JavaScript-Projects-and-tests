===========================================================================
===========================================================================
---THE---------------------------------------------------------------------
     ______  __   __              _____   _______   _    _   __  __
    |  ____| \ \ / /     /\      / ____| |__   __| | |  | | |  \/  |
    | |__     \ V /     /  \    | (___      | |    | |  | | | \  / |
    |  __|     > <     / /\ \    \___ \     | |    | |  | | | |\/| |
    | |____   / . \   / ____ \   ____) |    | |    | |__| | | |  | |
    |______| /_/ \_\ /_/    \_\ |_____/     |_|     \____/  |_|  |_|

----------------------------------------------------------------PROJECT----
==WELCOME=TO=EXASTUM=======================================================

Welcome to eXastum 2.0 Nova, the HTML5 Desktop Environment by Brian Millar.

To begin simply open the index.html in Google Chrome or Chromium.
(I'm working hard to add Firefox support, only a few bugs left.)

Setup will run and you can choose options to get up and running.

--NOTES--------------------------------------------------------------------

If you are confused by any part of the system or just can't 
get something to work the way it should then please send an
email to brianmillar9@yahoo.com and help will be provided, 
there is now a new Facebook page for Ontropy Software you
can find it at facebook.com/ontropy.

---LICENCE-----------------------------------------------------------------

By using this software you agree to the terms of
the GNU General Public Licence v3 and the extra
terms I have added under Section 7 (deals with 
giving credit in your forks).

---THANK-YOU---------------------------------------------------------------

Enjoy using eXastum and thank you for your interest in the project.

===========================================================================
===========================================================================
===========================================================================
